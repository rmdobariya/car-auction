<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('assets/media/logos/favicon.png')); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/media/logos/favicon.png')); ?>" type="image/x-icon">
    <title>Admin - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap"
          rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap"
          rel="stylesheet">
    <?php echo $__env->make('admin.layouts2.authentication.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
    <script>
        var APP_URL = <?php echo json_encode(url('/admin')); ?>;
        var default_message = "<?php echo e(trans('admin_string.common_default_message')); ?>"
        var replace_message = "<?php echo e(trans('admin_string.common_replace_message')); ?>"
        var file_remove = "<?php echo e(trans('admin_string.common_file_remove')); ?>"
        var file_error_message = "<?php echo e(trans('admin_string.common_file_error_message')); ?>"
    </script>
</head>
<body id="kt_body" class="bg-body">
<!-- login page start-->
<?php echo $__env->yieldContent('content'); ?>
<!-- latest jquery-->
<?php echo $__env->make('admin.layouts2.authentication.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\admin-template\resources\views/admin/layouts2/authentication/master.blade.php ENDPATH**/ ?>