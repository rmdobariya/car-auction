<div data-kt-swapper="true" data-kt-swapper-mode="prepend"
     data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
     class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
    <h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1"><?php echo e($main_name); ?></h1>
    
    
    
    
    
    
    
    
    
    
    
    
</div>
<?php /**PATH C:\laragon\www\admin-template\resources\views/admin/layouts2/components/bread-crumbs.blade.php ENDPATH**/ ?>