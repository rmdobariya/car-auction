<div class="d-flex align-items-center gap-2 gap-lg-3">






    <a href="<?php echo e($url); ?>" class="btn btn-sm btn-primary">Create</a>
</div>
<?php /**PATH C:\laragon\www\admin-template\resources\views/admin/layouts2/components/create-button.blade.php ENDPATH**/ ?>