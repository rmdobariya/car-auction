<?php $__env->startComponent('mail::message'); ?>
    # Hello <?php echo e($details['name']); ?>,
    Full Name : <?php echo e($details['full_name']); ?>

    Address : <?php echo e($details['address']); ?>

    Contact Number : <?php echo e($details['contact_number']); ?>

    Message : <?php echo e($details['message']); ?>

    Thanks
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\admin-template\resources\views/emails/contact_us.blade.php ENDPATH**/ ?>