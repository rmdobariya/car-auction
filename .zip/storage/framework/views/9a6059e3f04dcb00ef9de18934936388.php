<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1"><?php echo e(date("Y")); ?>©</span>
            <a href="#" target="_blank" class="text-gray-800 text-hover-primary">Admin Template</a>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\admin-template\resources\views/admin/layouts2/simple/footer.blade.php ENDPATH**/ ?>