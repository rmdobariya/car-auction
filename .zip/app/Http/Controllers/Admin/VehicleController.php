<?php

namespace App\Http\Controllers\Admin;


use App\Helpers\ImageUploadHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CategoryStoreRequest;
use App\Models\Blog;
use App\Models\Category;
use App\Models\Vehicle;
use App\Models\VehicleDocument;
use App\Models\VehicleImage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\AdminDataTableButtonHelper;
use Yajra\DataTables\Facades\DataTables;

class VehicleController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:vehicle-read|vehicle-create|vehicle-update|vehicle -delete', ['only' => ['index']]);
        $this->middleware('permission:vehicle-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:vehicle-update', ['only' => ['edit', 'update']]);
        $this->middleware('permission:vehicle-delete', ['only' => ['destroy']]);
    }

    public function index()
    {
        return view('admin.vehicle.index');
    }

//    public function create()
//    {
//        return view('admin.vehicle.create');
//    }


    public function destroy($id): JsonResponse
    {
        Vehicle::where('id', $id)->delete();
        return response()->json([
            'message' => 'Vehicle Delete Successfully'
        ]);
    }

    public function getVehicleList(Request $request)
    {
        if ($request->ajax()) {
            $vehicle = DB::table('vehicles')
                ->leftJoin('users', 'vehicles.user_id', 'users.id')
                ->leftjoin('model_has_roles', 'users.id', 'model_has_roles.model_id')
                ->leftjoin('roles', 'model_has_roles.role_id', 'roles.id')
                ->orderBy('id', 'desc');

            if (!empty($request->status) && $request->status !== 'all') {
                $vehicle->where('vehicles.status', $request->status);
            }

            if (!empty($request->deleted)) {
                if ((int)$request->deleted === 1) {
                    $vehicle->whereNotNull('vehicles.deleted_at');
                } else {
                    $vehicle->whereNull('vehicles.deleted_at');

                }
            }
            $vehicle = $vehicle->select('vehicles.*', 'users.name as user_name', 'roles.name as role_name');
            return Datatables::of($vehicle)
                ->addColumn('action', function ($vehicle) {

                    if (is_null($vehicle->deleted_at)) {
                        $array = [
                            'id' => $vehicle->id,
                            'actions' => [
//                                'edit' => route('admin.category.edit', [$category->id]),
                                'detail-page' => route('admin.vehicle.show', [$vehicle->id]),
                                'delete' => $vehicle->id,
                                'status' => $vehicle->status,
                            ]
                        ];
                    } else {
                        $array = [
                            'id' => $vehicle->id,
                            'actions' => [
                                'hard-delete' => $vehicle->id,
                                'restore' => $vehicle->id,
                            ]
                        ];
                    }
                    return AdminDataTableButtonHelper::actionButtonDropdown($array);
                })
                ->addColumn('status', function ($vehicle) {
                    $array['status'] = $vehicle->status;
                    return AdminDataTableButtonHelper::statusBadge($array);
                })
                ->addColumn('check', function ($vehicle) {

                    return '<td>
                    <div class="form-check form-check-sm form-check-custom form-check-solid">
                        <input class="form-check-input" type="checkbox" value=' . $vehicle->id . '>
                    </div>
                </td>';
                })
                ->addColumn('image', function ($vehicle) {

                    return '<img src="' . asset($vehicle->main_image) . '" style="width:50px">';
                })
                ->rawColumns(['action', 'status', 'check', 'image'])
                ->make(true);
        }
    }

    public function changeStatus($id, $status): JsonResponse
    {
        Vehicle::where('id', $id)->update(['status' => $status]);
        return response()->json([
            'message' => 'Status Change Successfully',
        ]);
    }

    public function restore($id): JsonResponse
    {
        DB::table('vehicles')->where('id', $id)->update([
            'deleted_at' => null
        ]);
        return response()->json([
            'message' => 'Vehicle Restore Successfully'
        ]);
    }

    public function hardDelete($id): JsonResponse
    {
        DB::table('vehicles')->where('id', $id)->delete();
        return response()->json([
            'message' => 'Vehicle Delete Successfully'
        ]);
    }

    public function show($id)
    {
        $vehicle = DB::table('vehicles')
            ->leftJoin('users','vehicles.user_id','users.id')
            ->leftJoin('vehicle_categories','vehicles.vehicle_category_id','vehicle_categories.id')
            ->where('vehicles.id', $id)
            ->select('vehicles.*','users.name as user_name','vehicle_categories.name as category_name')
            ->first();
        $vehicle_images = VehicleImage::where('vehicle_id', $id)->get();
        $vehicle_documents = VehicleDocument::where('vehicle_id', $id)->get();
        return view('admin.vehicle.show', [
            'vehicle' => $vehicle,
            'vehicle_images' => $vehicle_images,
            'vehicle_documents' => $vehicle_documents,
        ]);
    }
}
