<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\BlogResource;
use App\Models\Blog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $blog = Blog::where('status', 'active')->get();
        $result = BlogResource::collection($blog);
        return response()->json([
            'data' => $result,
        ]);
    }
}
