<div class="card-toolbar">
    <div class="w-100 mw-150px">
        <select class="form-select form-select-solid status-filter min-w-100px"
                id="status"
                data-control="select2"
                data-hide-search="true"
                data-placeholder="Status"
                data-kt-ecommerce-product-filter="Status">
            <option></option>
            <option value="all">All</option>
            <option value="active">Active</option>
            <option value="inActive">Inactive</option>
        </select>
    </div>
</div>
