@yield('css')

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
<link href="{{asset('assets/plugins/global/plugins.bundle.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{asset('assets/css/style.bundle.css')}}" rel="stylesheet" type="text/css"/>

<script src="https://unpkg.com/feather-icons"></script>
