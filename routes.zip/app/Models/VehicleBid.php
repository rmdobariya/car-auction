<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VehicleBid extends Model
{
    protected $guarded = [];
}
