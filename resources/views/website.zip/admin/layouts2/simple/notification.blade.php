<a href="#">
    <div class="notification-box">
        <i class="fa fa-bell-o"  style="font-size: 20px"></i>
        <span class="badge rounded-pill badge-secondary custom-notification">13</span>
    </div>
</a>
