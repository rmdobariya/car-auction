<button type="button" class="btn btn-light-primary me-3 text-white text-center"
        style="background-color: #673aaa !important;" data-kt-menu-trigger="click"
        data-kt-menu-placement="bottom-end">
    {{--                                    <i class="ki-duotone ki-filter fs-2"><span class="path1"></span><span--}}
    {{--                                            class="path2"></span></i>--}}
    {{trans('admin_string.filter')}}
</button>
