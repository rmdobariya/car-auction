@extends('admin.layouts2.simple.master')
@section('content')
    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="toolbar" id="kt_toolbar">
            <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
                @include('admin.layouts2.components.bread-crumbs',['main_name'=>trans('admin_string.vehicle_bids')])
            </div>
        </div>
        <div class="post d-flex flex-column-fluid" id="kt_post">
            <div id="kt_content_container" class="container-fluid">
                <div class="card">
                    <div class="card-body pt-0">
                        <table class="table align-middle table-row-dashed fs-6 gy-5" id="basic-1">
                            <thead>
                            <tr class="text-start text-dark-400 fw-bolder fs-7 text-uppercase gs-0">
                                <th>{{trans('admin_string.id')}}</th>
                                <th>{{trans('admin_string.user')}}</th>
                                <th>{{trans('admin_string.role')}}</th>
                                <th>{{trans('admin_string.name')}}</th>
                                <th>{{trans('admin_string.amount')}}</th>
                                <th>{{trans('admin_string.payment_proof')}}</th>
                                <th>{{trans('admin_string.is_winner')}}</th>
                                <th>{{trans('admin_string.status')}}</th>
                                <th>{{trans('admin_string.action')}}</th>
                            </tr>
                            </thead>
                            <tbody class="fw-bold text-gray-600"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('custom-script')
    <script>
        const datatable_url = '/get-bid-list'

        $.extend(true, $.fn.dataTable.defaults, {
            columns: [
                {data: 'id', name: 'vehicles.id'},
                {data: 'user_name', name: 'users.name'},
                {data: 'user_type', name: 'users.user_type'},
                {data: 'vehicle_name', name: 'vehicle_translations.name'},
                {data: 'amount', name: 'vehicle_bids.amount'},
                {data: 'vehicle_bid_payment_detail', name: 'vehicle_bid_payment_detail'},
                {data: 'is_winner', name: 'is_winner'},
                {data: 'status', name: 'vehicles.status'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            order: [[0, 'DESC']],
        })
    </script>

    <script src="{{URL::asset('assets/admin/custom/datatable.js')}}?v={{ time() }}"></script>
@endsection
