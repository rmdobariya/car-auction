<section id="news">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="title ">
                    <h1 class="text-white">News</h1>
                </div>
            </div>
            <div class="col-md-12">
                <div class="testimonial">
                    <div class="container">
                        <div class="testimonial__inner">
                            <div class="testimonial-slider">
                                <div class="testimonial-slide">
                                    <div class="testimonial_box">
                                        <div class="testimonial_box-inner">
                                            <div class="testimonial_box-top">
                                                <div class="testimonial_box-text">
                                                    <div class="date">
                                                        <span>Aug 20, 2023</span>
                                                    </div>
                                                    <h1>'lorem ipsum' will uncover many web sites still in their infancy</h1>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                                    <a href="#">Read Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="testimonial-slide">
                                    <div class="testimonial_box">
                                        <div class="testimonial_box-inner">
                                            <div class="testimonial_box-top">
                                                <div class="testimonial_box-text">
                                                    <div class="date">
                                                        <span>Aug 20, 2023</span>
                                                    </div>
                                                    <h1>'lorem ipsum' will uncover many web sites still in their infancy</h1>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                                    <a href="#">Read Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="testimonial-slide">
                                    <div class="testimonial_box">
                                        <div class="testimonial_box-inner">
                                            <div class="testimonial_box-top">
                                                <div class="testimonial_box-text">
                                                    <div class="date">
                                                        <span>Aug 20, 2023</span>
                                                    </div>
                                                    <h1>'lorem ipsum' will uncover many web sites still in their infancy</h1>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                                    <a href="#">Read Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="testimonial-slide">
                                    <div class="testimonial_box">
                                        <div class="testimonial_box-inner">
                                            <div class="testimonial_box-top">
                                                <div class="testimonial_box-text">
                                                    <div class="date">
                                                        <span>Aug 20, 2023</span>
                                                    </div>
                                                    <h1>'lorem ipsum' will uncover many web sites still in their infancy</h1>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                                    <a href="#">Read Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
