<section id="howworks">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="title">
                    <h1>How it Works</h1>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-md-4">
                <div class="work-box">
                    <span>1</span>
                    <h2>Register</h2>
                    <p>Sign up for a Copart Middle East Standard or Premier Membership</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <span>2</span>
                    <h2>Find</h2>
                    <p>Search our large inventory of used & damaged vehicles</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box">
                    <span>3</span>
                    <h2>Bid</h2>
                    <p>Bid in our online auctionsacross the Middle East</p>
                </div>
            </div>
        </div>
    </div>
</section>
