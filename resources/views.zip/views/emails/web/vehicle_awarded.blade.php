@component('mail::message')
    # Hello {{ $details['user_name'] }},
    {{$details['message']}}
    Thanks
    Zodha
@endcomponent
